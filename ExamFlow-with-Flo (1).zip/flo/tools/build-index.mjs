// Rebuilds knowledge/index.json from the chapter files (optional helper).
// Usage: node flo/tools/build-index.mjs   (run from the repository root)
// You can also edit index.json by hand: a chapter only NEEDS id, class, subject, name, file.
// Topics and FAQs in the index make search faster; Flo fills them in itself if they're missing.
import fs from "fs";
import path from "path";
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "../knowledge");
const old = fs.existsSync(path.join(root, "index.json")) ? JSON.parse(fs.readFileSync(path.join(root, "index.json"), "utf8")) : {};
const aliases = {};
(old.chapters || []).forEach((c) => (aliases[c.id] = c.aliases || []));
const files = [];
(function walk(d) { fs.readdirSync(d).forEach((f) => { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (f.endsWith(".json") && !["index.json", "general.json"].includes(f)) files.push(p); }); })(root);
const chapters = files.sort().map((p) => {
  const c = JSON.parse(fs.readFileSync(p, "utf8"));
  return {
    id: c.id, class: c.class ?? null, subject: c.subject, name: c.name,
    aliases: aliases[c.id] || c.aliases || [],
    file: path.relative(root, p).split(path.sep).join("/"),
    topics: (c.topics || []).map((t) => ({ id: t.id, title: t.title, keywords: t.keywords || [] })),
    faqs: (c.faqs || []).map((f) => ({ q: f.q, keywords: f.keywords || [] })),
    quizCount: (c.quiz || []).length,
  };
});
const index = { version: 1, general: "general.json", subjects: old.subjects || {}, chapters };
fs.writeFileSync(path.join(root, "index.json"), JSON.stringify(index, null, 1));
console.log(`index.json: ${chapters.length} chapters`);
