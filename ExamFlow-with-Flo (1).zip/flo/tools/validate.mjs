// Checks chapter files: node flo/tools/validate.mjs <file.json> [...]
import fs from "fs";
let bad = 0;
const files = process.argv.slice(2);
for (const f of files) {
  const errs = [];
  let d;
  try { d = JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { console.log("✗", f, "INVALID JSON", e.message); bad++; continue; }
  for (const k of ["id", "class", "subject", "name", "summary", "topics", "keyConcepts", "formulas", "commonMistakes", "revision", "faqs", "quiz"]) if (!(k in d)) errs.push("missing " + k);
  const ids = new Set();
  (d.topics || []).forEach((t, i) => {
    for (const k of ["id", "title", "summary", "simple", "explain", "example", "keyPoints", "keywords"]) if (!t[k] || (Array.isArray(t[k]) && !t[k].length)) errs.push(`topic ${i} missing ${k}`);
    if (ids.has(t.id)) errs.push("dup topic id " + t.id);
    ids.add(t.id);
  });
  const counts = [0, 0, 0, 0];
  (d.quiz || []).forEach((q, i) => {
    if (!Array.isArray(q.options) || q.options.length !== 4) errs.push(`quiz ${i}: need 4 options`);
    if (!(Number.isInteger(q.answer) && q.answer >= 0 && q.answer <= 3)) errs.push(`quiz ${i}: bad answer`);
    else counts[q.answer]++;
    if (!ids.has(q.topic)) errs.push(`quiz ${i}: unknown topic ${q.topic}`);
    if (!q.explain) errs.push(`quiz ${i}: no explain`);
    if (new Set(q.options || []).size !== (q.options || []).length) errs.push(`quiz ${i}: duplicate options`);
  });
  (d.faqs || []).forEach((q, i) => { if (!q.q || !q.a || !q.keywords?.length) errs.push(`faq ${i} incomplete`); });
  const walk = (v, p) => {
    if (typeof v === "string") { if (/^\s*\|.*\|/m.test(v)) errs.push("table-like text at " + p); }
    else if (Array.isArray(v)) v.forEach((x, i) => walk(x, p + "[" + i + "]"));
    else if (v && typeof v === "object") for (const k in v) walk(v[k], p + "." + k);
  };
  walk(d, "");
  if ((d.quiz || []).length < 10) errs.push("fewer than 10 quiz questions");
  if (errs.length) { bad++; console.log("✗", f); errs.forEach((e) => console.log("   -", e)); }
  else console.log("✓", f, `${d.topics.length} topics, ${d.quiz.length} quiz (answers A/B/C/D: ${counts.join("/")}), ${d.faqs.length} faqs`);
}
process.exit(bad ? 1 : 0);
